import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentComponent } from './student/student.component';
import { AdmissionFormComponent } from './admission-form/admission-form.component';

const routes: Routes = [
   { path: 'student', component: StudentComponent },
  { path: 'addmissionForm', component: AdmissionFormComponent },
 
  { path: '', redirectTo: '/student', pathMatch: 'full' },
  { path: '**', component: StudentComponent },
  
];

@NgModule({
  imports: [ RouterModule.forRoot(routes ,{useHash: false}) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}