export interface IStudent{
    name:string,
    lastName:string,
    class:string,
    year:number,
    percentage:number

  }