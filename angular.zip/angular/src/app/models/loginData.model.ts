export class LoginData {
    email: string;
    pwd : string;
}