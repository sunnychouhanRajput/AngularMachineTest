export class Employees {
    id: number;
    name: string;
    gender: string;
    email?: string;
    phoneNumbr?: number;
    contactPreference: string;
    dateOfBirth: Date;
    department: string;
    isActive: boolean;
    photoPath: string;
}