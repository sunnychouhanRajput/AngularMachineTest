package Puzzles;

import java.util.Scanner;

public class ConsecutiveSum {
	
	static int consecutive(long num) {
		int consecutiveSum = 0;
		long halfNum=num/2;
		for(int i=1;i<=halfNum;i++) {
			long temp =0;
			for(int j=i;j<=halfNum+1;j++) {
				temp += j;
				
				if(temp==num) {
					
					consecutiveSum=consecutiveSum+1;
					break;
				}
			}
			
		}
		System.out.println(consecutiveSum);
		
		return consecutiveSum;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		long num = sc.nextLong();
		
		consecutive( num);
		
		  sc.close();
		
		
		
	}
	
}
