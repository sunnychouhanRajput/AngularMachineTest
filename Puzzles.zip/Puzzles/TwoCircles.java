package Puzzles;

import java.util.Scanner;

public class TwoCircles {
	
	static String[] circles(String[] info) {
		for(int i=0;i<info.length;i++) {
			System.out.println(info[i]);
		}
		
		return info;
	}


public static void main (String[] args) {
	
	    Scanner sc = new Scanner(System.in);
	    int testCase = sc.nextInt();
	    String[] info= new String[testCase];
	    
	    for(int i=0;i<testCase;i++) {
	    	
	    	double X1 = sc.nextDouble();
		    double Y1 = sc.nextDouble();
		    double radius1 = sc.nextDouble();
		    
		    double X2 = sc.nextDouble();
		    double Y2 = sc.nextDouble();
		    double radius2 = sc.nextDouble();    
		    double distance = Math.pow((X1 - X2) * (X1 - X2) + (Y1 - Y2) * (Y1 - Y2), 0.5);
		    if (radius2 >= radius1 && distance <= (radius2 - radius1)){
		        
		        info[i]="Touching";
		    }
		    else if (radius1 >= radius2 && distance <= (radius1 - radius2) ) {
		    	info[i]="InterSecting";
		        
		    }
		    else if (distance > (radius1 + radius2)){
		    	info[i]="Disjoint-Outside";
		        
		    }
		    else {
		    	info[i]="InterSecting";
		        }
		    }
	    
	    circles(info);
	    sc.close();

	    }
	   
	    	}