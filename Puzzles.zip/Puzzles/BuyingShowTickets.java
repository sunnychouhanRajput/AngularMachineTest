package Puzzles;

import java.util.Scanner;

public class BuyingShowTickets {
	static long waitingTime(int[] tickets, int p) {
		long count = 0;
		int i = 0;
		int arrlength = tickets.length;
		while (tickets[p] != 0) {
			if (tickets[i] != 0) {
				count++;
				tickets[i] = tickets[i] - 1;
			}
			i++;
			if (i == arrlength) {
				i = 0;
			}
		}
		System.out.println(count);
		return count;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();

		int[] tickets = new int[num];
		for (int i = 0; i < num; i++) {
			tickets[i] = sc.nextInt();
		}
		int p = sc.nextInt();

		waitingTime(tickets, p);
		  sc.close();

	}

}
