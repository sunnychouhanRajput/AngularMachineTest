package Puzzles;
import java.util.Scanner;

public class LargestSubsetSum {

	static long[] maxSubsetSum(int[] K) {
		int arraylen = K.length;
		long[] SubSetarray = new long[arraylen];
		for( int j=0;j<arraylen;j++) {
		int sum = 0;
		int data = K[j];
		int LIM = (int) Math.sqrt(data);
		
		for (int i = 1; i <= LIM; i++) {
			if (data % i == 0) {

				if (i == (data/ i))
					sum += i;
				else
					sum += (i + data / i);
			}
		}
		SubSetarray[j]=sum;
		System.out.println(SubSetarray[j]);
		}
		return SubSetarray;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int[] DataArray=new int[num];
		for(int i=0;i<num;i++) {
			DataArray[i]=sc.nextInt();
		}
		
		maxSubsetSum(DataArray);
		sc.close();
		}
}