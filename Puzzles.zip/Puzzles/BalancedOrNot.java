package Puzzles;

import java.util.Scanner;
import java.util.Stack;

public class BalancedOrNot {

public static int[] isBalanced(String[] expressions , int[] maxReplacement) {
	int expressionLength=expressions.length;
	int resultArr[] = new int[expressionLength];
	for(int j=0;j<expressionLength;j++) {
		String s=expressions[j];
   int len=s.length();
    if(len==0 || s==null) return resultArr;
      Stack<Character> stack = new Stack<Character>();
    for(int i=0;i<s.length();i++)
    {
        if(s.charAt(i)=='<' )  stack.push(s.charAt(i));
        else if(s.charAt(i)=='>' && !stack.isEmpty() && stack.peek()!='>' ) stack.pop();
        else if(s.charAt(i)=='>'  )  stack.push(s.charAt(i));
        else if(s.charAt(i)=='<'  )  stack.push(s.charAt(i));
      
    }
    if(maxReplacement[j]>= stack.size()) {
    	resultArr[j]=1;
    }
    else {
    	resultArr[j]=0;
    }
    
   
    System.out.println(resultArr[j]);
    }
	return resultArr;
}
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int t = sc.nextInt();
    String expression[]=new String[t];
    for (int i = 0; i < t; i++) {
    	expression[i] = sc.next();
         
         
    }
    int m= sc.nextInt();
    int[] maxReplacement = new int[m];
    for (int i = 0; i < t; i++) {
    	maxReplacement[i] = sc.nextInt();
         
         
    }
    
    isBalanced(expression , maxReplacement);
    sc.close();
}
}