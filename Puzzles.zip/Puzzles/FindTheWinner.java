package Puzzles;

import java.util.Scanner;

public class FindTheWinner {

	static String Winner(int[] AndreaArray, int[] MariaArray, String s) {
		int andreaTotal = 0;
		int mariaTotal = 0;
		int AndreaArraylen = AndreaArray.length;

		if (s.equalsIgnoreCase("even")) {
			for (int i = 0; i < AndreaArraylen; i++) {
				andreaTotal = AndreaArray[i] - MariaArray[i];
				mariaTotal = MariaArray[i] - AndreaArray[i];
				i += 2;
			}
			if (andreaTotal > mariaTotal) {

				return "Andrea";
			} else {

				return "Maria";
			}
		} else {
			for (int i = 1; i < AndreaArraylen; i++) {
				andreaTotal = AndreaArray[i] - MariaArray[i];
				mariaTotal = MariaArray[i] - AndreaArray[i];
				i += 2;
			}
			if (mariaTotal > andreaTotal) {

				return "Maria";
			} else {

				return "Andrea";
			}

		}

	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int AndreaArraylen = sc.nextInt();
		int[] AndreaArray = new int[AndreaArraylen];
		for (int i = 0; i < AndreaArraylen; i++) {
			AndreaArray[i] = sc.nextInt();
		}

		int MariaArraylen = sc.nextInt();
		int[] MariaArray = new int[MariaArraylen];
		for (int i = 0; i < MariaArraylen; i++) {
			MariaArray[i] = sc.nextInt();
		}
		String cased = sc.next();
		String winners = "";
		winners = Winner(AndreaArray, MariaArray, cased);
		System.out.println(winners);
		  sc.close();
	}

}
