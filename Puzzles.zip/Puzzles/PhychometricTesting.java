package Puzzles;

import java.util.Scanner;

public class PhychometricTesting {
	static int[] jobOffers(int[] scores , int[] lowerLimits , int[] upperLimits) {
		int arrLength = lowerLimits.length;
		int finalArray[] = new int[arrLength];
		for(int i=0;i<arrLength;i++) {
			int count=0;
			for(int j=0;j<scores.length;j++) {
				if( scores[j]>=lowerLimits[i] && scores[j]<=upperLimits[i]) {
					count++;
				}
				
			}
			finalArray[i]=count;
			System.out.println(count);
		}
		
		return finalArray;
		
	}
	public static void main (String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int[] scores = new int[num];
		for(int i=0;i<num;i++) {
			scores[i]=sc.nextInt();
		}
		int lowLimitLen = sc.nextInt();
		int [] lowerLimits= new int[lowLimitLen];
		for(int i=0;i<lowLimitLen;i++) {
			lowerLimits[i]=sc.nextInt();
		}
		int upperLimitLen = sc.nextInt();
		int [] upperLimits= new int[upperLimitLen];
		for(int i=0;i<upperLimitLen;i++) {
			upperLimits[i]=sc.nextInt();
		}
		jobOffers(scores,lowerLimits,upperLimits);
		  sc.close();
		
	}

}
