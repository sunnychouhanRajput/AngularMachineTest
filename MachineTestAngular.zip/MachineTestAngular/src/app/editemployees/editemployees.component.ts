import { Component, OnInit } from '@angular/core';
import { Router ,ActivatedRoute } from '@angular/router';
import {EmployeeService} from '../employees/employeeById.service';
import { IEmployee } from '../employees/employee';
import { filter } from 'rxjs/operators';



@Component({
  selector: 'app-editemployees',
  templateUrl: './editemployees.component.html',
  styleUrls: ['./editemployees.component.css'],
  providers: [EmployeeService]
})
export class EditemployeesComponent implements OnInit, IEmployee {
  
   model ={};
  id: number;
  name: string;
  phone: string;
  city: string;
  address_line1: string;
  address_line2: string;
  postal_code: number;
  employees: IEmployee[];
  paramdata:number=0;
  isnotNumber = false;
  statusMessage: string = '';

  constructor(private router : Router ,private _empService: EmployeeService ,private routePath: ActivatedRoute) { 
 this.routePath.params.subscribe((params)=> this.paramdata  =params.id);
  console.log(this.paramdata);
     
 }
  

  ngOnInit() {  
   this.routePath.params.forEach(params => {
                    this.paramdata = params["id"];  
                    this.getUserInfo();
                    })
                    //call your function, like getUserInfo()

     }
     getUserInfo(){
     this._empService.getEmployees(this.paramdata).subscribe((employeesData)=>this.employees=employeesData.filter(person => person.id == this.paramdata) 
      ,(error)=>{
     this.statusMessage = 'Problem with the server please try later';
       console.error(error);
     });   
     
     
     }
      checkNumber(num: number):boolean{
      if(isNaN(num)){
      return true;
      }
      return false;
      }
  
 
  
 

  
 
  
  
  onSubmit(){
  console.log(this.model);
  console.log(this.employees);
  this.router.navigate(['/employee']);
  }
  
  
  }
  


  

