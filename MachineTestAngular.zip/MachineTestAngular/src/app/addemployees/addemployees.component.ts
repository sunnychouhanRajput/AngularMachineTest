import { IEmployee } from '../employees/employee';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-addemployees',
  templateUrl: './addemployees.component.html',
  styleUrls: ['./addemployees.component.css']
})
export class AddemployeesComponent implements OnInit, IEmployee {
  address: {};
  model = {};
  id: number;
  name: string;
  phone: string;
  city: string;
  address_line1: string;
  address_line2: string;
  postal_code: number;
 
  constructor(private router: Router) {}

  ngOnInit() {
  }

  onSubmit(){
  console.log(this.model);

  this.router.navigate(['/employee']);
  }

  }
