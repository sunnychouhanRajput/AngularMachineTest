import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing';
import {HttpModule} from '@angular/http';


import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { AddEmployeeComponent } from './employees/add-employee/add-employee.component';
import { AddemployeesComponent } from './addemployees/addemployees.component';
import { EditemployeesComponent } from './editemployees/editemployees.component';
import { PageNotFound } from './PageNotFound/PageNotFound.component';
import { EmployeeNumberValidationPipe } from './customFilters/NumberValidation.pipe';
import { EmployeeSearchPipe } from './customFilters/employeeSearch.pipe';

import {EmployeebyidService} from './Services/employeeById.service';
import {EmployeeService} from './Services/employee.service';


@NgModule({
  declarations: [
    AppComponent,
    EmployeesComponent,
    AddEmployeeComponent,
    AddemployeesComponent,
    EditemployeesComponent,
    PageNotFound,
    EmployeeNumberValidationPipe,
    EmployeeSearchPipe
    
  ],
  imports: [
    BrowserModule ,FormsModule ,AppRoutingModule ,HttpModule
  ],
  providers: [EmployeeService ,EmployeebyidService],
  bootstrap: [AppComponent]
})
export class AppModule { }
