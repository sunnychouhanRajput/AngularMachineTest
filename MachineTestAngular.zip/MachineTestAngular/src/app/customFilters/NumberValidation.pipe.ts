import { Pipe , PipeTransform } from '@angular/core';
@Pipe({
  name:'numberValidation',
  
})

export class EmployeeNumberValidationPipe implements PipeTransform {
  transform(value: string, phone: number):string {
    if(isNaN( phone )){
    return 'NA';
    }
    else{
     return value;
    }
  }

  
  
}