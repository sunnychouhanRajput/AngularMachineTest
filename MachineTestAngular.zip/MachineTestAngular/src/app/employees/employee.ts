export interface IEmployee{
  id: number ; 
   name: string ; 
  phone:string ; 

   city: string ; 
  address_line1: string ; 
  address_line2: string ;
  postal_code: number ;
}