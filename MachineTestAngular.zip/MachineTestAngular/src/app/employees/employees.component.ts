import { Component, OnInit } from '@angular/core';
import { IEmployee } from "./employee";
import {EmployeeService} from './employee.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css'],
    providers:[EmployeeService]
})
export class EmployeesComponent implements OnInit, IEmployee {
  id: number;
  name: string;
  phone: string;
  city: string;
  address_line1: string;
  address_line2: string;
  postal_code: number;
  employees: IEmployee[];
  search: string='';

  statusMessage: string = 'loading data Please Wait...';

  
  constructor(private _empService: EmployeeService) { }

  ngOnInit() {
     this._empService.getEmployees().subscribe((employeesData) => this.employees = employeesData, (error) => {
     this.statusMessage ='Problem with the server please try later';
       console.error(error);
     });

  }


  trackByCode(index : number , employee:any):string{
  return employee.empCode;
}

}
