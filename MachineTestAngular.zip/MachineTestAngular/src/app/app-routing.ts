import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeesComponent } from './employees/employees.component';
import { AddEmployeeComponent } from './employees/add-employee/add-employee.component';
import { AddemployeesComponent } from './addemployees/addemployees.component';
import { EditemployeesComponent } from './editemployees/editemployees.component';
import { PageNotFound } from './PageNotFound/PageNotFound.component';

const routes: Routes = [
   { path: 'employee', component: EmployeesComponent ,
 
  
  children: [
      { path: '', redirectTo: 'employee', pathMatch: 'full' },
     
        { path: ':id/edit', component: EditemployeesComponent }
       
    ]
  
  },
  { path: 'employee/add', component: AddemployeesComponent },
 
  { path: '', redirectTo: '/employee', pathMatch: 'full' },
  { path: '**', component: PageNotFound },
  
];

@NgModule({
  imports: [ RouterModule.forRoot(routes ,{useHash: false}) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}